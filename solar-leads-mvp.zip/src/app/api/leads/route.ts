import { NextResponse } from "next/server";

type LeadInput = {
  name: string;
  owner: boolean;
  roofArea: number;
  powerUsage: number;
};

function calculateScore(lead: LeadInput) {
  let score = 0;
  if (lead.owner) score += 25;
  if (lead.roofArea >= 40) score += 20;
  if (lead.powerUsage >= 4000) score += 20;
  return Math.min(score, 100);
}

function scoreLabel(score: number) {
  if (score >= 61) return "GREEN";
  if (score >= 31) return "YELLOW";
  return "RED";
}

export async function POST(req: Request) {
  const lead = await req.json();
  const score = calculateScore(lead);

  return NextResponse.json({
    ...lead,
    score,
    label: scoreLabel(score),
    status: "NEW",
    createdAt: new Date(),
  });
}